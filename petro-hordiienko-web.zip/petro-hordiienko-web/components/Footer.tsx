import type { Dictionary } from "@/content/types";
import { site } from "@/lib/site";

export function Footer({ t }: { t: Dictionary }) {
  const { legal } = site;
  return (
    <footer className="site-footer">
      <div className="wrap">
        <p className="legal">
          {legal.name} · NIP {legal.nip} · REGON {legal.regon}
          <br />
          {legal.address} · {t.footer.ceidg}
        </p>
        <p className="legal">
          © {new Date().getFullYear()} {site.name}
          <br />
          {t.footer.built}
        </p>
      </div>
    </footer>
  );
}
