/** The Frame mark: brackets around a block — code that contains an idea. */
export function Logo({
  size = 32,
  tone = "dark",
  className,
}: {
  size?: number;
  /** "dark" = for night backgrounds (light-pine brackets), "light" = for paper backgrounds (deep-pine brackets). */
  tone?: "dark" | "light";
  className?: string;
}) {
  const stroke = tone === "dark" ? "#4fb39c" : "#0f5a4c";
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} className={className} aria-hidden="true">
      <g fill="none" stroke={stroke} strokeWidth="4.6" strokeLinecap="square">
        <path d="M22 10H10V54H22" />
        <path d="M42 10H54V54H42" />
      </g>
      <rect x="27" y="27" width="10" height="10" fill="#f0b65a" />
    </svg>
  );
}
