import type { Dictionary } from "@/content/types";

export function Manifesto({ t }: { t: Dictionary }) {
  const m = t.manifesto;
  return (
    <section className="manifesto" aria-labelledby="manifesto-label">
      <div className="wrap">
        <p className="label" id="manifesto-label">
          {m.label}
        </p>
        <p className="manifesto-text">{m.text}</p>
        <dl className="facts">
          {m.facts.map((f) => (
            <div key={f.k}>
              <dt>{f.k}</dt>
              <dd>{f.v}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
