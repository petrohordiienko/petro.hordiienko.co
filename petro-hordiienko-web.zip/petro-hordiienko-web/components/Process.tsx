import type { Dictionary } from "@/content/types";
import { SectionHead } from "./SectionHead";

export function Process({ t }: { t: Dictionary }) {
  const p = t.process;
  return (
    <section id="process">
      <div className="wrap">
        <SectionHead label={p.label} title={p.title} />
        <ol className="steps">
          {p.steps.map((step) => (
            <li key={step.title}>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
        <div className="models">
          {p.models.map((m) => (
            <div key={m.title}>
              <p className="label">{p.modelLabel}</p>
              <h3>{m.title}</h3>
              <p>{m.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
