"use client";

import { useEffect, useRef, useState } from "react";
import type { Dictionary } from "@/content/types";
import { FORMS, ParticleField, type FormName } from "@/lib/particles";
import { site } from "@/lib/site";

export function Hero({ t }: { t: Dictionary }) {
  const sectionRef = useRef<HTMLElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fieldRef = useRef<ParticleField | null>(null);
  const [form, setForm] = useState<FormName>("knot");
  const [webgl, setWebgl] = useState<"pending" | "on" | "off">("pending");

  useEffect(() => {
    const canvas = canvasRef.current;
    const section = sectionRef.current;
    if (!canvas || !section) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let created: ParticleField | null = null;
    try {
      created = new ParticleField(canvas, { onFormChange: setForm, reducedMotion: reduced, autoCycleMs: 8000 });
    } catch {
      created = null;
    }
    if (!created) {
      setWebgl("off");
      return;
    }
    const field = created;
    fieldRef.current = field;
    setWebgl("on");

    const layout = () => {
      const wide = window.innerWidth >= 900;
      // Desktop: form sits right of the headline. Phone: form sits above it, smaller.
      if (wide) field.setLayout(0.5, 0.04, 0.82);
      else field.setLayout(0, 0.3, 0.6);
      field.resize();
    };
    layout();

    const ro = new ResizeObserver(layout);
    ro.observe(canvas);

    const toNdc = (e: PointerEvent | MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      return { x: ((e.clientX - r.left) / r.width) * 2 - 1, y: -(((e.clientY - r.top) / r.height) * 2 - 1) };
    };
    const onMove = (e: PointerEvent) => {
      const p = toNdc(e);
      field.setPointer(p.x, p.y, true);
    };
    const onLeave = () => field.setPointer(0, 0, false);
    const onDown = (e: PointerEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("a,button")) return;
      const p = toNdc(e);
      field.burst(p.x, p.y);
    };
    section.addEventListener("pointermove", onMove);
    section.addEventListener("pointerleave", onLeave);
    section.addEventListener("pointerdown", onDown);

    const onScroll = () => {
      const r = section.getBoundingClientRect();
      field.setScatter(-r.top / Math.max(1, r.height) * 1.4);
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    // Only animate while the hero is on screen and the tab is visible.
    let visible = true;
    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible && !document.hidden) field.play();
      else field.pause();
    });
    io.observe(section);
    const onVis = () => (document.hidden || !visible ? field.pause() : field.play());
    document.addEventListener("visibilitychange", onVis);

    field.play();

    return () => {
      ro.disconnect();
      io.disconnect();
      section.removeEventListener("pointermove", onMove);
      section.removeEventListener("pointerleave", onLeave);
      section.removeEventListener("pointerdown", onDown);
      window.removeEventListener("scroll", onScroll);
      document.removeEventListener("visibilitychange", onVis);
      field.destroy();
      fieldRef.current = null;
    };
  }, []);

  return (
    <section className="hero" ref={sectionRef} data-webgl={webgl}>
      <canvas ref={canvasRef} className="hero-canvas" role="img" aria-label={t.hero.canvasLabel} />

      <div className="wrap hero-inner">
        <ul className="hero-notes">
          {t.hero.notes.map((note) => (
            <li key={note}>{note}</li>
          ))}
        </ul>

        <div className="hero-copy">
          <h1>
            <span>{t.hero.titleTop}</span>
            <span>
              {t.hero.titleBottom}
              <i className="cur" aria-hidden="true" />
            </span>
          </h1>
          <p className="lede">{t.hero.lede}</p>
          <div className="ctas">
            <a className="btn btn-accent" href="#contact">
              {t.hero.ctaBook}
            </a>
            <a className="btn btn-line" href="#services">
              {t.hero.ctaServices}
            </a>
          </div>
        </div>

        {webgl === "on" ? (
          <div className="hero-controls">
            <div className="forms" role="group" aria-label={t.hero.formLabel}>
              <span className="forms-label">{t.hero.formLabel}</span>
              {FORMS.map((f) => (
                <button
                  key={f}
                  type="button"
                  aria-pressed={form === f}
                  onClick={() => fieldRef.current?.setForm(f)}
                >
                  {t.hero.forms[f]}
                </button>
              ))}
            </div>
            <p className="hint">{t.hero.hint}</p>
          </div>
        ) : null}
      </div>
      <span className="sr-only">{site.name}</span>
    </section>
  );
}
