"use client";

import { useEffect, useRef, useState } from "react";

export function CopyEmail({ email, copy, copied }: { email: string; copy: string; copied: string }) {
  const [done, setDone] = useState(false);
  const codeRef = useRef<HTMLElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const selectText = () => {
    const node = codeRef.current;
    const sel = window.getSelection();
    if (!node || !sel) return;
    const range = document.createRange();
    range.selectNodeContents(node);
    sel.removeAllRanges();
    sel.addRange(range);
  };

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(email);
      setDone(true);
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => setDone(false), 1600);
    } catch {
      selectText();
    }
  };

  return (
    <div className="email">
      <a href={`mailto:${email}`}>
        <code ref={codeRef}>{email}</code>
      </a>
      <button type="button" className="copy" onClick={onCopy} aria-live="polite">
        {done ? copied : copy}
      </button>
    </div>
  );
}
