import type { Dictionary } from "@/content/types";
import { site } from "@/lib/site";
import { CopyEmail } from "./CopyEmail";

export function Contact({ t }: { t: Dictionary }) {
  const c = t.contact;
  return (
    <section id="contact" className="contact">
      <div className="wrap contact-grid">
        <div>
          <p className="label">{c.label}</p>
          <h2>{c.title}</h2>
          <p className="sub">{c.sub}</p>
          <CopyEmail email={site.email} copy={c.copy} copied={c.copied} />
          <a className="btn btn-accent" href={site.calendar} target="_blank" rel="noopener noreferrer">
            {t.hero.ctaBook}
          </a>
          <p className="note">{c.note}</p>
        </div>
        <ul className="links">
          {site.socials.map((s) => (
            <li key={s.label}>
              <a href={s.href} target="_blank" rel="noopener noreferrer me">
                {s.label} <span>{s.handle}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
