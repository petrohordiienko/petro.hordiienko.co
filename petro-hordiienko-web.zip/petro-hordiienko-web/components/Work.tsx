import type { Dictionary } from "@/content/types";
import { SectionHead } from "./SectionHead";

export function Work({ t }: { t: Dictionary }) {
  const w = t.work;
  return (
    <section id="work">
      <div className="wrap">
        <SectionHead label={w.label} title={w.title} sub={w.sub} />
        <ol className="record">
          {w.items.map((item) => (
            <li key={`${item.company}-${item.when}`}>
              <span className="when">{item.when}</span>
              <span className="company">{item.company}</span>
              <span className="domain">{item.domain}</span>
              <span className="role">{item.role}</span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
