import Link from "next/link";
import type { Dictionary } from "@/content/types";
import { locales, type Locale } from "@/lib/i18n";
import { site } from "@/lib/site";
import { Logo } from "./Logo";

export function Header({ lang, t }: { lang: Locale; t: Dictionary }) {
  return (
    <header className="site-header">
      <div className="wrap bar">
        <a className="brand" href="#top" aria-label={site.name}>
          <Logo size={30} />
          <span>{site.name}</span>
        </a>
        <nav aria-label="Sections">
          <a href="#services">{t.nav.services}</a>
          <a href="#work">{t.nav.work}</a>
          <a href="#process">{t.nav.process}</a>
          <a href="#contact">{t.nav.contact}</a>
        </nav>
        <div className="lang" role="group" aria-label={t.nav.language}>
          {locales.map((l) => (
            <Link key={l} href={`/${l}`} hrefLang={l} aria-current={l === lang ? "true" : undefined}>
              {l.toUpperCase()}
            </Link>
          ))}
        </div>
      </div>
    </header>
  );
}
