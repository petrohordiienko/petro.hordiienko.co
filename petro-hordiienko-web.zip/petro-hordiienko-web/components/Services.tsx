import type { Dictionary } from "@/content/types";
import { SectionHead } from "./SectionHead";

export function Services({ t }: { t: Dictionary }) {
  const s = t.services;
  return (
    <section id="services">
      <div className="wrap">
        <SectionHead label={s.label} title={s.title} sub={s.sub} />
        <ul className="services">
          {s.items.map((item) => (
            <li className="service" key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.body}</p>
              <p className="tech">{item.tech}</p>
            </li>
          ))}
        </ul>
        <div className="cto">
          <p>
            <strong>{s.cto.strong}</strong>
            {s.cto.body}
          </p>
          <a className="btn btn-ghost" href="#contact">
            {s.cto.cta}
          </a>
        </div>
      </div>
    </section>
  );
}
