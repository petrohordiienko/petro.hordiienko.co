export function SectionHead({ label, title, sub }: { label: string; title: string; sub?: string }) {
  return (
    <div className="sec-head">
      <p className="label">{label}</p>
      <div>
        <h2>{title}</h2>
        {sub ? <p>{sub}</p> : null}
      </div>
    </div>
  );
}
