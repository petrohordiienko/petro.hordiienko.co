import type { Dictionary } from "./types";
import { en } from "./en";

export const pl: Dictionary = {
  meta: {
    title: "Petro Hordiienko · Niezależne studio oprogramowania",
    description:
      "Niezależne studio oprogramowania z Poznania. Aplikacje webowe i mobilne, backend, chmura, AI i blockchain, tworzone przez doświadczonego inżyniera i byłego CTO.",
  },
  nav: { services: "Usługi", work: "Doświadczenie", process: "Proces", contact: "Kontakt", language: "Język" },
  hero: {
    notes: ["Niezależne studio oprogramowania", "Od 2016", "52.41° N · 16.93° E — Poznań"],
    titleTop: "Pomysły,",
    titleBottom: "w produkcji.",
    lede: "Oprogramowanie, systemy i AI dla zespołów, które działają szybko. Doświadczenie seniora bez narzutu agencji.",
    ctaBook: "Rozpocznij projekt",
    ctaServices: "Co tworzymy",
    formLabel: "Forma",
    forms: { knot: "Węzeł", orbit: "Orbita", signal: "Sygnał" },
    hint: "Porusz kursorem · kliknij, by rozproszyć",
    canvasLabel: "Interaktywne pole cząsteczek 3D",
  },
  manifesto: {
    label: "Studio",
    text: "Małe studio z jedną osobą odpowiedzialną za wynik. Doświadczony inżynier prowadzi każdy projekt od pierwszego szkicu do produkcji, a zaufanych specjalistów angażuje tylko wtedy, gdy praca tego wymaga.",
    facts: [
      { k: "Tworzymy od", v: "2016" },
      { k: "Były CTO", v: "Giełda kryptowalut" },
      { k: "Principal engineer", v: "Platforma danych AI" },
      { k: "Praca", v: "Zdalnie · CET" },
    ],
  },
  services: {
    label: "Usługi",
    title: "Kompleksowe usługi IT",
    sub: "Od pierwszego prototypu po systemy obsługujące prawdziwe pieniądze i prawdziwy ruch.",
    items: [
      { title: "Aplikacje webowe", body: "Produkty SaaS, panele i platformy: szybkie, dostępne i gotowe na rozwój.", tech: en.services.items[0].tech },
      { title: "Aplikacje mobilne", body: "Wieloplatformowe aplikacje na iOS i Androida, dzielące kod z produktem webowym.", tech: en.services.items[1].tech },
      { title: "Backend i API", body: "Usługi, integracje i systemy czasu rzeczywistego projektowane z myślą o obciążeniu i zmianach.", tech: en.services.items[2].tech },
      { title: "Chmura i DevOps", body: "Infrastruktura jako kod, CI/CD, monitoring i wysoka dostępność w dowolnej chmurze.", tech: en.services.items[3].tech },
      { title: "Integracja AI", body: "Funkcje LLM, agenci i RAG, które rozwiązują mierzalny problem w Twoim produkcie.", tech: en.services.items[4].tech },
      { title: "Blockchain i fintech", body: "Giełdy, silniki transakcyjne, portfele i płatności z bezpieczeństwem od podstaw.", tech: en.services.items[5].tech },
      { title: "Inżynieria danych", body: "Potoki danych, jakość danych i podstawy analityki, na których można oprzeć decyzje.", tech: en.services.items[6].tech },
      { title: "Doradztwo i audyty", body: "Przeglądy architektury, audyty kodu i dostawców, techniczne due diligence.", tech: "Architektura · Bezpieczeństwo · Skala" },
    ],
    cto: {
      strong: "Fractional CTO.",
      body: " Przywództwo techniczne kilka dni w miesiącu: roadmapa, rekrutacja, architektura i rozmowy z inwestorami.",
      cta: "Porozmawiajmy o projekcie",
    },
  },
  work: {
    label: "Doświadczenie",
    title: "Skąd pochodzi doświadczenie",
    sub: "Wybrane role. Pełna historia na LinkedIn.",
    items: [
      { ...en.work.items[0], domain: "Platforma danych AI" },
      { ...en.work.items[1], domain: "Strumieniowanie audio na żywo" },
      { ...en.work.items[2], domain: "Giełda kryptowalut, Dubaj" },
      { ...en.work.items[3], domain: "Giełda kryptowalut, Dubaj" },
      { ...en.work.items[4], domain: "Studio MVP" },
      { ...en.work.items[5], domain: "SaaS, VoIP, logistyka" },
    ],
  },
  process: {
    label: "Proces",
    title: "Jasne kroki, działające oprogramowanie co tydzień",
    steps: [
      { title: "Rozmowa wstępna", body: "30 minut o celu, użytkownikach i ograniczeniach. Bez przygotowania." },
      { title: "Zakres i wycena", body: "Krótki plan na piśmie: architektura, kamienie milowe, ryzyka i widełki kosztów." },
      { title: "Budowa etapami", body: "Cotygodniowe demo na środowisku testowym. Postęp, który można kliknąć, a nie raporty." },
      { title: "Start i przekazanie", body: "Wdrożenie produkcyjne, dokumentacja i wsparcie albo przekazanie projektu Twojemu zespołowi." },
    ],
    modelLabel: "Współpraca",
    models: [
      { title: "MVP o stałym zakresie", body: "Uzgodniony zakres i cena pierwszej wersji." },
      { title: "Miesięczny kontrakt B2B", body: "Stały rozwój, faktura co miesiąc." },
      { title: "Dni doradcze", body: "Czas fractional CTO, audyty i przeglądy." },
    ],
  },
  contact: {
    label: "Kontakt",
    title: "Masz pomysł? Zbudujmy go.",
    sub: "Napisz, nad czym pracujesz i w czym potrzebujesz pomocy.",
    copy: "Kopiuj",
    copied: "Skopiowano",
    note: "Każde zapytanie czyta osobiście Petro.",
  },
  footer: { ceidg: "Wpis do CEIDG", built: "Ręcznie napisany WebGL, bez bibliotek." },
};
