export type Dictionary = {
  meta: { title: string; description: string };
  nav: { services: string; work: string; process: string; contact: string; language: string };
  hero: {
    notes: string[];
    titleTop: string;
    titleBottom: string;
    lede: string;
    ctaBook: string;
    ctaServices: string;
    formLabel: string;
    forms: { knot: string; orbit: string; signal: string };
    hint: string;
    canvasLabel: string;
  };
  manifesto: {
    label: string;
    text: string;
    facts: { k: string; v: string }[];
  };
  services: {
    label: string;
    title: string;
    sub: string;
    items: { title: string; body: string; tech: string }[];
    cto: { strong: string; body: string; cta: string };
  };
  work: {
    label: string;
    title: string;
    sub: string;
    items: { when: string; role: string; company: string; domain: string }[];
  };
  process: {
    label: string;
    title: string;
    steps: { title: string; body: string }[];
    modelLabel: string;
    models: { title: string; body: string }[];
  };
  contact: { label: string; title: string; sub: string; copy: string; copied: string; note: string };
  footer: { ceidg: string; built: string };
};
