import type { Dictionary } from "./types";

export const en: Dictionary = {
  meta: {
    title: "Petro Hordiienko · Independent software studio",
    description:
      "Independent software studio from Poznań. Web and mobile apps, backend, cloud, AI and blockchain, built by a senior engineer and former CTO.",
  },
  nav: { services: "Services", work: "Track record", process: "Process", contact: "Contact", language: "Language" },
  hero: {
    notes: ["Independent software studio", "Est. 2016", "52.41° N · 16.93° E — Poznań"],
    titleTop: "Ideas,",
    titleBottom: "engineered.",
    lede: "Software, systems and AI for teams that move fast. Senior engineering without the agency overhead.",
    ctaBook: "Start a project",
    ctaServices: "What we build",
    formLabel: "Form",
    forms: { knot: "Knot", orbit: "Orbit", signal: "Signal" },
    hint: "Move to disturb · click to scatter",
    canvasLabel: "Interactive 3D particle field",
  },
  manifesto: {
    label: "Studio",
    text: "A small studio with a single point of responsibility. One senior engineer leads every project from the first sketch to production, and brings in trusted specialists only when the work needs them.",
    facts: [
      { k: "Building since", v: "2016" },
      { k: "Former CTO", v: "Crypto exchange" },
      { k: "Principal engineer", v: "AI data platform" },
      { k: "Works", v: "Remote · CET" },
    ],
  },
  services: {
    label: "Services",
    title: "Full-cycle IT services",
    sub: "From a first prototype to systems that handle real money and real traffic.",
    items: [
      { title: "Web applications", body: "SaaS products, dashboards and platforms that are fast, accessible and easy to grow.", tech: "React · Next.js · TypeScript" },
      { title: "Mobile apps", body: "Cross-platform iOS and Android apps that share one codebase with your web product.", tech: "React Native · Flutter" },
      { title: "Backend & APIs", body: "Services, integrations and real-time systems designed for load and for change.", tech: "Go · Node.js · Python · gRPC" },
      { title: "Cloud & DevOps", body: "Infrastructure as code, CI/CD, monitoring and high availability on any cloud.", tech: "Kubernetes · Terraform · AWS · GCP" },
      { title: "AI integration", body: "LLM features, agents and RAG that solve a measurable problem inside your product.", tech: "LLM · RAG · MCP · agents" },
      { title: "Blockchain & fintech", body: "Exchanges, trading engines, wallets and payment flows with security built in.", tech: "Solidity · EVM · Web3" },
      { title: "Data engineering", body: "Pipelines, data quality and analytics foundations you can trust for decisions.", tech: "ETL · PostgreSQL · ELK" },
      { title: "Consulting & audits", body: "Architecture reviews, code and vendor audits, technical due diligence.", tech: "Architecture · Security · Scale" },
    ],
    cto: {
      strong: "Fractional CTO.",
      body: " Senior technical leadership a few days a month: roadmap, hiring, architecture and investor conversations.",
      cta: "Discuss your project",
    },
  },
  work: {
    label: "Track record",
    title: "Where the experience comes from",
    sub: "Selected roles. Full history on LinkedIn.",
    items: [
      { when: "2024–25", role: "Principal Engineer", company: "Octocleanse", domain: "AI data platform" },
      { when: "2024–25", role: "Senior Engineer", company: "Wowsy", domain: "Real-time audio streaming" },
      { when: "2022–23", role: "CTO", company: "Exbi Trade", domain: "Crypto exchange, Dubai" },
      { when: "2021–22", role: "Senior Engineer", company: "Bistox Exchange", domain: "Crypto exchange, Dubai" },
      { when: "2020–21", role: "CTO & Co-founder", company: "DevStation", domain: "MVP studio" },
      { when: "2016–21", role: "Engineer", company: "Chanty · Voypost · MaybeWorks", domain: "SaaS, VoIP, logistics" },
    ],
  },
  process: {
    label: "Process",
    title: "Clear steps, working software every week",
    steps: [
      { title: "Intro call", body: "30 minutes about your goal, users and constraints. No preparation needed." },
      { title: "Scope & estimate", body: "A short written plan: architecture, milestones, risks and a cost range." },
      { title: "Build in increments", body: "Weekly demos on a staging environment. Progress you can click, not status reports." },
      { title: "Launch & handover", body: "Production release, documentation and support, or a handover to your team." },
    ],
    modelLabel: "Engagement",
    models: [
      { title: "Fixed-scope MVP", body: "Agreed scope and price for a first version." },
      { title: "Monthly B2B contract", body: "Ongoing engineering, invoiced monthly." },
      { title: "Advisory days", body: "Fractional CTO time, audits and reviews." },
    ],
  },
  contact: {
    label: "Contact",
    title: "Have an idea? Let's build it.",
    sub: "Tell us what you are working on and where you are stuck.",
    copy: "Copy",
    copied: "Copied",
    note: "Every enquiry is read by Petro personally.",
  },
  footer: { ceidg: "Registered in CEIDG", built: "Hand-built WebGL, no libraries." },
};
