import { notFound } from "next/navigation";
import { getDictionary, isLocale } from "@/lib/i18n";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { Manifesto } from "@/components/Manifesto";
import { Services } from "@/components/Services";
import { Work } from "@/components/Work";
import { Process } from "@/components/Process";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

export default async function Home({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLocale(lang)) notFound();
  const t = getDictionary(lang);

  return (
    <>
      <Header lang={lang} t={t} />
      <main id="top">
        <Hero t={t} />
        <Manifesto t={t} />
        <Services t={t} />
        <Work t={t} />
        <Process t={t} />
        <Contact t={t} />
      </main>
      <Footer t={t} />
    </>
  );
}
