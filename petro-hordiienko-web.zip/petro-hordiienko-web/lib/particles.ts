/**
 * Dependency-free WebGL particle field.
 * Particles spring towards a target "form" (a torus knot, an orbit, a signal wave),
 * are pushed away by the pointer, scatter on click and drift apart as the hero scrolls away.
 */

export type FormName = "knot" | "orbit" | "signal";
export const FORMS: FormName[] = ["knot", "orbit", "signal"];

type Options = {
  onFormChange?: (form: FormName) => void;
  autoCycleMs?: number;
  reducedMotion?: boolean;
};

const PALETTE = {
  pine: [0.38, 0.82, 0.7],
  mist: [0.93, 0.95, 0.92],
  amber: [0.94, 0.71, 0.35],
  deep: [0.12, 0.42, 0.36],
} as const;

const VERT = `
attribute vec3 aPos;
attribute vec3 aColor;
attribute float aSeed;
uniform float uTime;
uniform float uDpr;
uniform float uAspect;
uniform vec2 uRot;
uniform vec2 uOffset;
uniform float uScale;
varying vec3 vColor;
varying float vAlpha;
void main() {
  vec3 p = aPos;
  float cy = cos(uRot.x), sy = sin(uRot.x);
  p = vec3(cy * p.x + sy * p.z, p.y, -sy * p.x + cy * p.z);
  float cx = cos(uRot.y), sx = sin(uRot.y);
  p = vec3(p.x, cx * p.y - sx * p.z, sx * p.y + cx * p.z);
  float depth = 2.6 - p.z;
  vec2 proj = p.xy * (2.2 / depth);
  proj.x /= uAspect;
  gl_Position = vec4(proj * uScale + uOffset, 0.0, 1.0);
  float twinkle = 0.75 + 0.25 * sin(uTime * 1.7 + aSeed * 40.0);
  gl_PointSize = (2.0 + aSeed * 2.8) * uDpr * (2.6 / depth) * twinkle * mix(0.75, 1.0, uScale);
  vColor = aColor;
  vAlpha = clamp(1.45 - depth * 0.25, 0.4, 1.0);
}`;

const FRAG = `
precision mediump float;
varying vec3 vColor;
varying float vAlpha;
void main() {
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  float a = smoothstep(0.5, 0.0, d);
  a = a * a;
  gl_FragColor = vec4(vColor * a * vAlpha, a * vAlpha);
}`;

function compile(gl: WebGLRenderingContext, type: number, src: string) {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? "shader");
  return s;
}

/** A (2,3) torus knot: one continuous strand that loops through itself, drawn as a tube of particles. */
function sampleKnot(n: number) {
  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  const P = 2;
  const Q = 3;
  const tube = 0.075;
  const point = (t: number) => {
    const r = 0.44 + 0.2 * Math.cos(Q * t);
    return [r * Math.cos(P * t), r * Math.sin(P * t), 0.2 * Math.sin(Q * t)];
  };
  for (let k = 0; k < n; k += 1) {
    const u = k / n;
    const t = u * Math.PI * 2;
    const c = point(t);
    const d = point(t + 0.001);
    // tangent and a perpendicular frame for the tube
    let tx = d[0] - c[0], ty = d[1] - c[1], tz = d[2] - c[2];
    const tl = Math.hypot(tx, ty, tz) || 1;
    tx /= tl; ty /= tl; tz /= tl;
    let nx = -ty, ny = tx, nz = 0;
    const nl = Math.hypot(nx, ny) || 1;
    nx /= nl; ny /= nl;
    const bx = ty * nz - tz * ny, by = tz * nx - tx * nz, bz = tx * ny - ty * nx;
    const a = Math.random() * Math.PI * 2;
    const rr = tube * Math.sqrt(Math.random());
    const ca = Math.cos(a) * rr, sa = Math.sin(a) * rr;
    pos.set([(c[0] + nx * ca + bx * sa) * 1.22, (c[1] + ny * ca + by * sa) * 1.22, (c[2] + nz * ca + bz * sa) * 1.22], k * 3);
    // one short amber segment travels along the strand as a "signal"
    const tint = u > 0.62 && u < 0.67 ? PALETTE.amber : Math.random() < 0.7 ? PALETTE.pine : PALETTE.mist;
    col.set(tint, k * 3);
  }
  return { pos, col };
}

function sampleOrbit(n: number) {
  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  const golden = Math.PI * (3 - Math.sqrt(5));
  const sphere = Math.floor(n * 0.72);
  for (let k = 0; k < n; k += 1) {
    if (k < sphere) {
      const y = 1 - (k / (sphere - 1)) * 2;
      const r = Math.sqrt(1 - y * y);
      const t = golden * k;
      const R = 0.68;
      pos.set([Math.cos(t) * r * R, y * R, Math.sin(t) * r * R], k * 3);
      col.set(Math.random() < 0.85 ? PALETTE.pine : PALETTE.mist, k * 3);
    } else {
      // a tilted ring around the sphere
      const a = Math.random() * Math.PI * 2;
      const R = 1.02 + (Math.random() - 0.5) * 0.06;
      const x = Math.cos(a) * R;
      const z = Math.sin(a) * R;
      pos.set([x, z * 0.28 + (Math.random() - 0.5) * 0.03, z * 0.96], k * 3);
      col.set(Math.random() < 0.4 ? PALETTE.amber : PALETTE.mist, k * 3);
    }
  }
  return { pos, col };
}

function sampleSignal(n: number) {
  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  const side = Math.ceil(Math.sqrt(n));
  for (let k = 0; k < n; k += 1) {
    const gx = (k % side) / (side - 1);
    const gz = Math.floor(k / side) / (side - 1);
    pos.set([(gx - 0.5) * 2.1 + 0.2, 0, (gz - 0.5) * 1.6], k * 3);
    col.set(gz > 0.82 && gx > 0.6 ? PALETTE.amber : gz < 0.5 ? PALETTE.deep : PALETTE.pine, k * 3);
  }
  return { pos, col };
}

export class ParticleField {
  private gl: WebGLRenderingContext;
  private canvas: HTMLCanvasElement;
  private n: number;
  private pos: Float32Array;
  private vel: Float32Array;
  private col: Float32Array;
  private seed: Float32Array;
  private forms: Record<FormName, { pos: Float32Array; col: Float32Array }>;
  private form: FormName = "knot";
  private posBuf: WebGLBuffer;
  private colBuf: WebGLBuffer;
  private uni: Record<string, WebGLUniformLocation | null>;
  private raf = 0;
  private running = false;
  private start = performance.now();
  private last = performance.now();
  private pointer = { x: 0, y: 0, active: false };
  private rot = { x: 0, y: 0, tx: 0, ty: 0 };
  private scatter = 0;
  private cycleAt = 0;
  private opts: Options;
  private dpr = 1;
  private aspect = 1;
  private layout = { x: 0, y: 0, s: 1 };

  constructor(canvas: HTMLCanvasElement, opts: Options = {}) {
    this.canvas = canvas;
    this.opts = opts;
    const gl =
      (canvas.getContext("webgl", { antialias: false, alpha: true, premultipliedAlpha: true }) as WebGLRenderingContext | null) ??
      (canvas.getContext("experimental-webgl") as WebGLRenderingContext | null);
    if (!gl) throw new Error("WebGL unavailable");
    this.gl = gl;

    const area = canvas.clientWidth * canvas.clientHeight;
    this.n = Math.round(Math.min(9000, Math.max(3500, area / 90)));

    this.forms = { knot: sampleKnot(this.n), orbit: sampleOrbit(this.n), signal: sampleSignal(this.n) };

    this.pos = new Float32Array(this.n * 3);
    this.vel = new Float32Array(this.n * 3);
    this.col = new Float32Array(this.forms.knot.col);
    this.seed = new Float32Array(this.n);
    for (let i = 0; i < this.n; i += 1) {
      this.seed[i] = Math.random();
      // start as a wide cloud so the first frame "assembles" the form
      this.pos[i * 3] = (Math.random() - 0.5) * 6;
      this.pos[i * 3 + 1] = (Math.random() - 0.5) * 4;
      this.pos[i * 3 + 2] = (Math.random() - 0.5) * 3;
    }
    if (opts.reducedMotion) this.pos.set(this.forms.knot.pos);

    const prog = gl.createProgram()!;
    gl.attachShader(prog, compile(gl, gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, compile(gl, gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog) ?? "link");
    gl.useProgram(prog);

    const bind = (name: string, data: Float32Array, size: number, usage: number) => {
      const buf = gl.createBuffer()!;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, data, usage);
      const loc = gl.getAttribLocation(prog, name);
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, 0, 0);
      return buf;
    };
    this.posBuf = bind("aPos", this.pos, 3, gl.DYNAMIC_DRAW);
    this.colBuf = bind("aColor", this.col, 3, gl.DYNAMIC_DRAW);
    bind("aSeed", this.seed, 1, gl.STATIC_DRAW);

    this.uni = {};
    for (const u of ["uTime", "uDpr", "uAspect", "uRot", "uOffset", "uScale"]) this.uni[u] = gl.getUniformLocation(prog, u);

    gl.disable(gl.DEPTH_TEST);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.blendFuncSeparate(gl.ONE, gl.ONE, gl.ONE, gl.ONE_MINUS_SRC_ALPHA);

    this.resize();
    this.cycleAt = performance.now() + (opts.autoCycleMs ?? 7000);
  }

  get count() {
    return this.n;
  }

  resize() {
    const { canvas, gl } = this;
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(canvas.clientWidth * this.dpr));
    const h = Math.max(1, Math.round(canvas.clientHeight * this.dpr));
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    this.aspect = w / h;
    gl.viewport(0, 0, w, h);
    if (!this.running) this.draw(performance.now());
  }

  /** Where the form sits in the canvas, in clip space (offset) and relative size. */
  setLayout(x: number, y: number, s: number) {
    this.layout = { x, y, s };
    if (!this.running) this.draw(performance.now());
  }

  private toWorld(x: number, y: number) {
    const { layout } = this;
    return { x: ((x - layout.x) / layout.s) * this.aspect * 1.18, y: ((y - layout.y) / layout.s) * 1.18 };
  }

  /** Pointer in normalised device coordinates (-1..1). */
  setPointer(x: number, y: number, active = true) {
    const w = this.toWorld(x, y);
    this.pointer.x = w.x;
    this.pointer.y = w.y;
    this.pointer.active = active;
    this.rot.tx = x * 0.35;
    this.rot.ty = -y * 0.22;
  }

  /** 0 = hero fully in view, 1 = scrolled away. */
  setScatter(v: number) {
    this.scatter = Math.max(0, Math.min(1, v));
  }

  burst(x: number, y: number) {
    const { x: wx, y: wy } = this.toWorld(x, y);
    for (let i = 0; i < this.n; i += 1) {
      const dx = this.pos[i * 3] - wx;
      const dy = this.pos[i * 3 + 1] - wy;
      const d = Math.sqrt(dx * dx + dy * dy) + 0.05;
      const f = 0.09 / d;
      this.vel[i * 3] += dx * f;
      this.vel[i * 3 + 1] += dy * f;
      this.vel[i * 3 + 2] += (this.seed[i] - 0.5) * 0.12;
    }
  }

  setForm(form: FormName) {
    if (form === this.form) return;
    this.form = form;
    this.cycleAt = performance.now() + (this.opts.autoCycleMs ?? 7000);
    this.opts.onFormChange?.(form);
    if (this.opts.reducedMotion) {
      this.pos.set(this.forms[form].pos);
      this.col.set(this.forms[form].col);
      this.draw(performance.now());
    }
  }

  nextForm() {
    this.setForm(FORMS[(FORMS.indexOf(this.form) + 1) % FORMS.length]);
  }

  play() {
    if (this.running || this.opts.reducedMotion) {
      this.draw(performance.now());
      return;
    }
    this.running = true;
    this.last = performance.now();
    const loop = (t: number) => {
      if (!this.running) return;
      this.step(t);
      this.draw(t);
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  pause() {
    this.running = false;
    cancelAnimationFrame(this.raf);
  }

  destroy() {
    this.pause();
    this.gl.getExtension("WEBGL_lose_context")?.loseContext();
  }

  private step(now: number) {
    const dt = Math.min(2, (now - this.last) / 16.67);
    this.last = now;
    if (this.opts.autoCycleMs !== 0 && now > this.cycleAt) this.nextForm();

    const time = (now - this.start) / 1000;
    const target = this.forms[this.form];
    const tp = target.pos;
    const tc = target.col;
    const isSignal = this.form === "signal";
    const k = 0.012 * dt;
    const damp = Math.pow(0.9, dt);
    const px = this.pointer.x;
    const py = this.pointer.y;
    const R2 = 0.11;
    const scatter = this.scatter;
    const { pos, vel, col, seed } = this;

    for (let i = 0; i < this.n; i += 1) {
      const o = i * 3;
      let tx = tp[o];
      let ty = tp[o + 1];
      let tz = tp[o + 2];
      if (isSignal) {
        ty = Math.sin(tx * 2.6 + time * 1.4) * 0.2 + Math.cos(tz * 3.4 - time) * 0.12;
        const ry = ty;
        ty = ry * 0.85 - tz * 0.52;
        tz = ry * 0.52 + tz * 0.85;
      }
      // idle breathing so the form never looks frozen
      const s = seed[i];
      tx += Math.sin(time * 0.9 + s * 31) * 0.006;
      ty += Math.cos(time * 0.7 + s * 17) * 0.006;
      // scroll scatter: push outwards along a per-particle direction
      if (scatter > 0) {
        const a = s * 6.283;
        tx += Math.cos(a) * scatter * (1.5 + s * 2);
        ty += Math.sin(a) * scatter * (1.2 + s * 1.5);
        tz += (s - 0.5) * scatter * 3;
      }

      let vx = vel[o] + (tx - pos[o]) * k;
      let vy = vel[o + 1] + (ty - pos[o + 1]) * k;
      let vz = vel[o + 2] + (tz - pos[o + 2]) * k;

      if (this.pointer.active) {
        const dx = pos[o] - px;
        const dy = pos[o + 1] - py;
        const d2 = dx * dx + dy * dy;
        if (d2 < R2) {
          const f = (1 - d2 / R2) * 0.012 * dt;
          const d = Math.sqrt(d2) + 1e-4;
          vx += (dx / d) * f;
          vy += (dy / d) * f;
          vz += f * 0.6;
        }
      }

      vx *= damp;
      vy *= damp;
      vz *= damp;
      vel[o] = vx;
      vel[o + 1] = vy;
      vel[o + 2] = vz;
      pos[o] += vx * dt;
      pos[o + 1] += vy * dt;
      pos[o + 2] += vz * dt;

      col[o] += (tc[o] - col[o]) * 0.04 * dt;
      col[o + 1] += (tc[o + 1] - col[o + 1]) * 0.04 * dt;
      col[o + 2] += (tc[o + 2] - col[o + 2]) * 0.04 * dt;
    }

    this.rot.x += (this.rot.tx + (this.form === "signal" ? 0 : time * 0.25) - this.rot.x) * 0.05;
    this.rot.y += (this.rot.ty - this.rot.y) * 0.05;
  }

  private draw(now: number) {
    const { gl } = this;
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.posBuf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.pos);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.colBuf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.col);
    gl.uniform1f(this.uni.uTime, (now - this.start) / 1000);
    gl.uniform1f(this.uni.uDpr, this.dpr);
    gl.uniform1f(this.uni.uAspect, this.aspect);
    gl.uniform2f(this.uni.uRot, this.rot.x, this.rot.y);
    gl.uniform2f(this.uni.uOffset, this.layout.x, this.layout.y);
    gl.uniform1f(this.uni.uScale, this.layout.s);
    gl.drawArrays(gl.POINTS, 0, this.n);
  }
}
