# hordiienko.co

Studio website for **Petro Hordiienko** (JDG, Poznań). Next.js App Router + TypeScript, English and Polish, with a hand-written WebGL particle hero. No runtime dependencies besides Next and React.

## Run it

```bash
npm install
npm run dev        # http://localhost:3000 → redirects to /en or /pl
npm run build && npm start
```

Node 18.18+ (Node 20 or 22 recommended).

## How it is organised

```
app/
  [lang]/layout.tsx           root layout: fonts, metadata, hreflang, JSON-LD
  [lang]/page.tsx             the one-page site
  [lang]/opengraph-image.tsx  1200×630 share image per language (LinkedIn, X, Slack)
  globals.css                 brand tokens + all styles
  icon.svg                    favicon (the Frame mark)
  sitemap.ts, robots.ts
components/
  Hero.tsx                    night hero + live particle field (client component)
  Manifesto, Services, Work, Process, Contact, Footer, Header
lib/particles.ts              the WebGL particle engine (no dependencies)
content/en.ts, content/pl.ts  ALL copy lives here (typed by content/types.ts)
lib/site.ts                   email, booking link, socials, NIP/REGON/address
lib/i18n.ts                   locales and dictionary lookup
middleware.ts                 "/" → /pl or /en (cookie first, then browser language)
```

- **Change text**: edit `content/en.ts` and `content/pl.ts`. TypeScript fails the build if the two files drift apart.
- **Change contacts or legal data**: edit `lib/site.ts`.
- **Change colours or fonts**: the tokens at the top of `app/globals.css` match the brand kit.

## The particle hero

`lib/particles.ts` is a hand-written WebGL renderer, about 400 lines, with no three.js or other libraries:

- 3,500–9,000 particles (scaled to screen size) spring towards one of three forms: **Knot** (a 3D (2,3) torus knot with an amber signal segment), **Orbit** (a Fibonacci sphere with a ring) and **Signal** (an animated wave surface). Forms change every 8 s or via the buttons.
- The cursor pushes particles away, a click scatters them, the scene tilts with the pointer, and scrolling down disperses the field.
- It pauses when the hero is off screen or the tab is hidden, caps the pixel ratio at 2, and respects `prefers-reduced-motion` (a still, fully formed knot).
- Without WebGL the hero keeps its dark background and grid, with no animation.

To tune it, change `setLayout(...)` in `components/Hero.tsx` (position and size of the form), the `PALETTE` colours, or add a new form by writing a `sample…()` function that returns positions and colours.

## Deploy

**Vercel (recommended):** import the repo, keep the defaults, then add `hordiienko.co` (and `www`) under *Settings → Domains* and point DNS at Vercel as it instructs. The language redirect on `/` uses middleware, which Vercel supports.

**Static hosting (no server):** add `output: "export"` to `next.config.ts` and run `npm run build`; upload `out/`. Middleware does not run in a static export, so add a redirect from `/` to `/en` in your host's config (or a small `public/index.html` that redirects).

If you deploy somewhere other than `https://hordiienko.co`, update `site.url` in `lib/site.ts` so canonical URLs, the sitemap and share images point to the right domain.

## Legal note

The footer shows the business name, NIP, REGON and registered address from CEIDG, as Polish law expects for a business website. The site sets no cookies except the language preference (`NEXT_LOCALE`) and runs no analytics. If you add analytics or a contact form, add a privacy policy (polityka prywatności) and, where needed, a cookie consent banner.
